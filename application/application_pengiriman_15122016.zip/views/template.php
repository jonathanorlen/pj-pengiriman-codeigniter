<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js"> 
<!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<title><?php echo $title; ?></title>

		<?php
			// place your script below ex:
			// // $this->load->view('template/script');
		?>

	</head>
	<body>

		<?php
			// load your content here ex:
			// // $this->load->view('template/header');
			echo $content;
			// // $this->load->view('template/footer');
		?>

		<?php
			// if you have script in footer, place below ex:
			// // $this->load->view('template/script_bottom');
		?>
	</body>
</html>