<!DOCTYPE html>
<html>
<head>
	<title>PRINT PENGIRIMAN</title>
</head>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<body onload="print()">
	<?php
	$kode = $this->uri->segment(3);

	$transaksi_penjualan = $this->db->get_where('transaksi_penjualan',array('kode_penjualan'=>$kode));
	$hasil_transaksi_penjualan = $transaksi_penjualan->row();
	$pengiriman = $this->db->get_where('transaksi_pengiriman',array('kode_penjualan'=>$kode));
	$hasil_pengiriman = $pengiriman->row();
	?>
	<table width="100%">
		<tr>
			<th colspan="6"><center>PATRIOT JAYA<center></th>
		</tr>
		<tr>
			<td width="14%">Kode Penjualan</td>
			<td width="1%">:</td>
			<td width="35%"><?php echo $hasil_transaksi_penjualan->kode_penjualan; ?></td>
			<td width="14%">Nama</td>
			<td width="1%">:</td>
			<td width="35%"><?php echo $hasil_transaksi_penjualan->nama_penerima; ?></td>
		</tr>
		<tr>
			<td>Tanggal Penjualan</td>
			<td>:</td>
			<td><?php echo TanggalIndo($hasil_transaksi_penjualan->tanggal_penjualan) ?></td>
			<td>No. Handphone</td>
			<td>:</td>
			<td><?php echo $hasil_transaksi_penjualan->no_telp ?></td>
		</tr>
		<tr>
			<td>Tanggal / Jam Kirim</td>
			<td>:</td>
			<td><?php echo TanggalIndo($hasil_transaksi_penjualan->tanggal_pengiriman)." / ".$hasil_transaksi_penjualan->jam_pengiriman ?></td>
			<td>Alamat</td>
			<td>:</td>
			<td><?php echo $hasil_transaksi_penjualan->alamat_penerima; ?></td>
		</tr>
		<tr>
			<td>Sopir / No.Kendaraan</td>
			<td>:</td>
			<td><?php echo $hasil_pengiriman->nama_sopir." / ".$hasil_pengiriman->no_kendaraan ?></td>
			<td></td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td colspan="6">
				<table class="table table-bordered" width="100%">
					<thead>
						<tr>
							<th width="5%">No</th>
							<th>Nama Produk</th>
							<th width="5%">QTY</th>
							<th>Harga</th>
							<th>Sub Total</th>
							<th>Diskon</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$kode = $this->uri->segment(3);
						$pembelian = $this->db->get_where('opsi_transaksi_penjualan',array('kode_penjualan'=>$kode));
						$list_pembelian = $pembelian->result();
						$nomor = 1;  $total = 0;

						foreach($list_pembelian as $daftar){ 
							?> 
							<tr>
								<td><?php echo $nomor; ?></td>
								<td><?php echo $daftar->nama_menu ?></td>
								<td><?php echo $daftar->jumlah; ?> <?php echo $daftar->nama_satuan; ?></td>
								<td><?php echo format_rupiah($daftar->harga_satuan); ?></td>
								<td><?php echo format_rupiah($daftar->subtotal); ?></td>
								<td><?php echo $daftar->diskon_item.' %'; ?></td>
							</tr>
							<?php 
							$total = $total + $daftar->subtotal;
							$nomor++; 
						} 
						?>
						<tr>
							<td colspan="4"></td>
							<td style="font-weight:bold;">Total</td>
							<td><?php echo format_rupiah($total); ?></td>
						</tr>

						<tr>
							<td colspan="4"></td>
							<td style="font-weight:bold;">Diskon (%)</td>
							<td id="tb_diskon"><?php echo $hasil_transaksi_penjualan->diskon_persen; ?></td></td>

						</tr>

						<tr>
							<td colspan="4"></td>
							<td style="font-weight:bold;">Diskon (Rp)</td>
							<td id="tb_diskon_rupiah"><?php echo format_rupiah($hasil_transaksi_penjualan->diskon_rupiah); ?></td>

						</tr>

						<tr>
							<td colspan="4"></td>
							<td style="font-weight:bold;">Grand Total</td>
							<td id="tb_grand_total"><?php echo format_rupiah($total-$hasil_transaksi_penjualan->diskon_rupiah); ?></td>

						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</table>
</body>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</html>