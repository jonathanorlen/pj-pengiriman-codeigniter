<?php 
$get_position = $this->uri->segment(2);
$position = ucwords($get_position);
?>
<div class="row">      
  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <a class="dashboard-stat dashboard-stat-light blue-soft" id="gudang">
      <div class="visual">
        <i class="glyphicon glyphicon-tasks" ></i>
      </div>
      <div class="details" >
        <div class="number">

        </div>
        <div class="desc">
          Gudang
        </div>
      </div>
    </a>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <a class="dashboard-stat dashboard-stat-light red-soft"  id="kitchen">
      <div class="visual">
        <i class="glyphicon glyphicon-shopping-cart"></i>
      </div>
      <div class="details">
        <div class="number">

        </div>
        <div class="desc">
          Kitchen
        </div>
      </div>
    </a>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <a class="dashboard-stat dashboard-stat-light green-soft"  id="bar">
      <div class="visual">
        <i class="glyphicon glyphicon-shopping-cart"></i>
      </div>
      <div class="details">
        <div class="number">

        </div>
        <div class="desc">
          Bar
        </div>
      </div>
    </a>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <a class="dashboard-stat dashboard-stat-light purple-soft"  id="serve">
      <div class="visual">
        <i class="glyphicon glyphicon-shopping-cart"></i>
      </div>
      <div class="details">
        <div class="number">

        </div>
        <div class="desc">
          Server
        </div>
      </div>
    </a>
  </div>
  <div class="col-xs-12">
    <!-- /.box -->
    <?php 
$position = $this->uri->segment(2);
if($position == 'detail' || $position == 'edit'){
	$position = $this->uri->segment(3);
}
?>
    

    <div class="portlet box blue">
      <div class="portlet-title">
        <div class="caption">
          Stok Gudang
        </div>
        <div class="tools">
          <a href="javascript:;" class="collapse">
          </a>
          <a href="javascript:;" class="reload">
          </a>

        </div>
      </div>
      <div class="portlet-body">
        <!------------------------------------------------------------------------------------------------------>


        <div class="box-body">            
          <div class="sukses" ></div>
          <a style="padding:13px; margin-bottom:10px;width: 100px" class="btn btn-app green" href="<?php echo base_url().'stok/'.$position; ?>"><i class="fa fa-edit"></i> Stok </a>
    <a style="padding:13px; margin-bottom:10px;width: 100px" class="btn btn-app blue" href="<?php echo base_url().'spoil/'.$position;?>"><i class="fa fa-edit"></i> Spoil </a>
    <!-- <a style="padding:13px; margin-bottom:10px;" class="btn btn-app red" href="<?php echo base_url().'retur_pembelian/gudang'; ?>"><i class="fa fa-edit"></i> Retur </a>
 -->
    <a style="padding:13px; margin-bottom:10px;width: 100px" class="btn btn-app red" href="<?php echo base_url().'mutasi/gudang'; ?>"><i class="fa fa-edit"></i> Mutasi </a>
    <a style="padding:13px; margin-bottom:10px;width: 100px" class="btn btn-warning" href="<?php echo base_url().'opname/gudang'; ?>"><i class="fa fa-edit"></i> Opname </a>

            <table class="table table-striped table-hover table-bordered" id="tabel_daftar"  style="font-size:1.5em;">
           <thead>
            <tr>
              <th>Kode Bahan</th>
              <th>Nama Bahan</th>
              <th>Nama Rak</th>
              <th align="right">Real Stok</th>
              <th align="right">Stok Min</th>
              <th>HPP</th>
              <th>Aset</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="daftar_list_stock">

            <?php

            $kode_default = $this->db->get('setting_gudang');
            $hasil_unit =$kode_default->row();
            $param=$hasil_unit->kode_unit;
             //$kode_unit =$this->uri->segment(3);
            // $get_rak = $this->db->get_where('master_rak',array('kode_unit' => $kode_unit));
            // $hasil_rak = $get_rak->row();

            $get_stok = $this->db->query("SELECT * from master_bahan_baku where kode_unit='$param'");
            $hasil_stok = $get_stok->result_array();
            foreach ($hasil_stok as $item) {

              $kode_bahan = $item['kode_bahan_baku']; 
              $this->db->select('*, min(id) id');                       
              $get_kode_bahan = $this->db->get_where('transaksi_stok',array('kode_bahan'=>$kode_bahan));
              $hasil_hpp_bahan = $get_kode_bahan->row();
              $get_stok_min = $this->db->get_where('master_bahan_baku',array('id'=>$item['id']));
              $hasil_stok_min = $get_stok_min->row();
                                  //echo count($hasil_stok_min);
              ?>   
              <tr <?php if($item['real_stock']<=$hasil_stok_min->stok_minimal){echo'class="danger"';}?>>
                <td><?php echo $item['kode_bahan_baku'];?></td>
                <td><?php echo $item['nama_bahan_baku'];?></td>
                 <td><?php echo $item['nama_rak'];?></td>
                <td align="right"><?php echo $item['real_stock'];?> <?php echo $item['satuan_stok'];?></td>
                <td align="right"><?php echo $item['stok_minimal'];?> <?php echo $item['satuan_stok'];?></td>
                
               
                <td><?php echo format_rupiah($hasil_hpp_bahan->hpp);?></td>
                <td><?php echo format_rupiah(($item['real_stock'] <= 0) ? ($hasil_hpp_bahan->hpp * 0) : ($hasil_hpp_bahan->hpp * $item['real_stock']));?></td>
                <td align="center">
                    <div class="btn-group">
                        <a href="<?php echo base_url().'stok/detail_stok_gudang/'.$item['id']; ?>" title="Detail" class="btn btn-icon-only btn-circle green">
                            <i class="fa fa-search"></i>
                        </a>
                    </div>
                </td>
              </tr>

              <?php } ?>
              
            </tbody>
            <tfoot>
              <tr>
                <th>Kode Bahan</th>
                <th>Nama Bahan</th>
                <th>Nama Rak</th>
                <th align="right">Real Stok</th>
                <th align="right">Stok Min</th>
                <th>HPP</th>
                <th>Aset</th>
                <th>Action</th>
              </tr>
            </tfoot>
            <tbody>

            </tbody>                
          </table>

          
        </div>
        
        <!------------------------------------------------------------------------------------------------------>

      </div>
    </div>
  </div><!-- /.col -->
</div>
</div>    
</div>  
<!-- /.content-wrapper -->
<!-- <style type="text/css" media="screen">
        .btn-back
          {
            position: fixed;
            bottom: 10px;
             left: 10px;
            z-index: 999999999999999;
                vertical-align: middle;
                cursor:pointer
          }
        </style>
                <img class="btn-back" src="<?php echo base_url().'component/img/back_icon.png'?>" style="width: 70px;height: 70px;">

        <script>
          $('.btn-back').click(function(){
            window.location = "<?php echo base_url().'stok/daftar'; ?>";
          });
        </script>
 -->
<script>
$(document).ready(function(){
   $("#gudang").click(function(){
                              window.location = "<?php echo base_url() . 'stok/gudang' ?>";

                            });

                            $("#bar").click(function(){
                              window.location = "<?php echo base_url() . 'stok/bar' ?>";
                            });

                            $("#kitchen").click(function(){
                              window.location = "<?php echo base_url() . 'stok/kitchen' ?>";
                            });

                            $("#serve").click(function(){
                              window.location = "<?php echo base_url() . 'stok/serve' ?>";
                            });

  $("#tabel_daftar").dataTable({
    "paging":   false,
    "ordering": false,
    "info":     false
  });


})


function list_stock(){
  var kode_rak = $('#kode_rak').val();
  var kode_unit = $('#kode_unit').val();
  var url = "<?php echo base_url(). 'stok/stok/list_stock'; ?>";
  $.ajax({
    type: "POST",
    url: url,
    data: {kode_rak:kode_rak,kode_unit,kode_unit},
    success: function(msg) {
                // alert(msg);
                $('#daftar_list_stock').html(msg);
              }
            });
}
$(".stok_min").css("background-color", "red");
</script>