<div class="portlet box blue">
      <div class="portlet-title">
        <div class="caption">
         Daftar Spoil
       </div>
       <div class="tools">
        <a href="javascript:;" class="collapse">
        </a>
        <a href="javascript:;" class="reload">
        </a>

      </div>
    </div>

    <div class="portlet-body">
      <!------------------------------------------------------------------------------------------------------>
       <a href="<?php echo base_url().'laporan_aktifitas/daftar' ?>" style="margin-left: 17px; padding: 15px; height: 75px;width: auto;" class="icon-btn btn red-flamingo">
													<i class="fa fa-arrow-left"></i>
													<div style="color: white;">
														 Kembali
													</div>
       </a>
      <div class="double bg-blue pull-right" style="cursor:default">
        <div class="tile-object">
          <div  style="padding-right:10px; padding-left:10px;  padding-top:10px; font-size:17px; font-family:arial; font-weight:bold">
            Total Transaksi Spoil
          </div>
        </div>

        
        <div  style="padding-right:10px; padding-top:0px; font-size:48px; font-family:arial; font-weight:bold">
          <?php
          $tgl_awal = $this->uri->segment(3);
          $tgl_akhir = $this->uri->segment(4);
          if($tgl_awal!=""&&$tgl_akhir!=""){
            $this->db->where('tanggal_spoil >=', $tgl_awal);
            $this->db->where('tanggal_spoil <=', $tgl_akhir);
          }          
           
           $total = $this->db->get('transaksi_spoil');
           $hasil_total = $total->num_rows();

          ?>
          <i class="total_transaksi"><?php echo $hasil_total; ?></i>
        </div>
      </div>
<br><br><br><br><br>
      <div class="box-body">            

        <div class="sukses"></div>
        <table class="table table-hover table-bordered" id="tabel_daftar" style="font-size:1.5em;">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Spoil</th>
                  <th>Tanggal Spoil</th>
                  <th>Petugas</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php
               if($tgl_awal!=""&&$tgl_akhir!=""){
                $this->db->where('tanggal_spoil >=', $tgl_awal);
                $this->db->where('tanggal_spoil <=', $tgl_akhir);
              } 
                $spoil = $this->db->get('transaksi_spoil');
                $list_spoil = $spoil->result();
                $nomor = 1;  

                foreach($list_spoil as $daftar){ 
                  ?> 
                  <tr>
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $daftar->kode_spoil; ?></td>
                    <td><?php echo $daftar->tanggal_spoil; ?></td>
                    <td><?php echo $daftar->petugas; ?></td>
                    
                  </tr>
                  <?php 
                  $nomor++; 
                } 
                ?>

              </tbody>
              <tfoot>
                <tr>
                  <th>No</th>
                  <th>Kode Spoil</th>
                  <th>Tanggal Spoil</th>
                  <th>Petugas</th>
                  
                </tr>
              </tfoot>            
            </table>
     

      <!------------------------------------------------------------------------------------------------------>

    </div>
  </div>
